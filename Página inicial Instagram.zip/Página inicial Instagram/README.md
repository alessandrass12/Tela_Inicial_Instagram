Tela inicial do Instagram, feita para o Bootcamp Decola Dev Avanade 2021.

Projeto feito com HTML e CSS puro. 